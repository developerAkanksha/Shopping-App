import React, { useState, useEffect } from 'react';
import UserHeader from './userheader';

const MyHome = () => {
    // http://localhost:1234/product
    let [product, updateProduct] = useState([]);
    const getProduct = () => {
        fetch("http://localhost:1234/product")
            .then(response => response.json())
            .then(productArray => {
                updateProduct(productArray);
            })
    }

    useEffect(() => {
        getProduct();
    }, [1]);

    const addToCart = (iteminfo)=>{
        var url = "http://localhost:1234/cart";
        var postData = {
            headers:{'Content-Type' : 'application/json'},
            body:JSON.stringify(iteminfo),
            method:"POST"
        };

        fetch(url,postData)
        .then(response=> response.json())
        .then(serverRes =>{
            updateMessage(iteminfo.name + "Added in cart")
        })

    } //add to cart and end here

    let[msg,updateMessage] = useState("");

    return (
        <>
            <UserHeader />
            <div className="container mt-4">
                <div className="row">
                    <div className="col-lg-12">
                        <p className="text-center text-danger"> {msg} </p>
                    </div>
                </div>
                <div className="row mt-3">
                    {
                        product.map((myproduct, index) => {
                            return (
                                <div className="col-lg-3 mb-4" key={index}>
                                    <h3 className="text-primary text-center"> {myproduct.name} </h3>
                                    <img src={myproduct.photo} className="img-fluid" height="200" />
                                    <p className="p-2"> Rs {myproduct.price} </p>
                                    <p>
                                        {myproduct.details}
                                    </p>
                                    <div className="text-center">
                                        <button className="btn btn-danger btn-sm"
                                            onClick = {addToCart.bind(this, myproduct)}>
                                             Add to cart
                                        </button>
                                    </div>
                                </div>
                            )

                        })
                    }
            </div>
            </div>
        </>
    );
}

export default MyHome;