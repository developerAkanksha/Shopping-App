import React from "react";
import { Link } from "react-router-dom";
const UserHeader = () => {
    return (
        <nav className="navbar navbar-expand-sm navbar-dark bg-dark p-3">
            <div className="container-fluid">
                <a className="navbar-brand">
                    <i className="fa fa-shopping-bag"></i> Keep@Buying
                </a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse">
                    <ul className="navbar-nav me-auto">
                        <li className="nav-item ps-4">
                            <Link className="nav-link active" to="/">
                                <i className="fa fa-home"></i> Home
                            </Link>
                        </li>
                        <li className="nav-item ps-4">
                            <Link className="nav-link active" to="/cart">
                                <i className="fa fa-shopping-cart"></i> My Cart
                            </Link>
                        </li>
                        <li className="nav-item ps-4">
                            <Link className="nav-link active" to="/login">
                                <i className="fa fa-lock"></i> Login
                            </Link>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>
    );
}

export default UserHeader;