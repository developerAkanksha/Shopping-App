import React from 'react';
import {Link} from 'react-router-dom';
const AdminHeader = () => {
    return(
        <div className="container mt-3 ">
            <div className="row">
                <div className="col-lg-4 text-center">
                    <i className="fa fa-shopping-bag fa-lg text-danger"> </i>
                    <h3> Keep@Buying </h3>
                </div>
                <div className="col-lg-8 text-end">
                    <div className="btn-group">
                        <Link className="btn btn-primary" to="/">
                            <i className="fa fa-home"></i> Dashboard
                        </Link>
                        <Link className="btn btn-primary" to="/product">
                            <i className="fa fa-suitcase"></i> Manage Products
                        </Link>
                        <Link className="btn btn-primary" to="/order">
                            <i className="fa fa-headset"></i> Manage Orders
                        </Link>
                        <button className="btn btn-danger" onClick={Logout}>
                            Welcome - {localStorage.getItem("fullname")}-
                            <i className="fa fa-power-off"> </i>Logout
                        </button>
                    </div>
                </div>
            </div>
           
        </div>
    );
}

export default AdminHeader;

const Logout = () =>{
    localStorage.clear();
    window.location.href="http://localhost:3000/#/login";
    //window.location.href="http://127.0.0.1:5500/#/login"; 
    window.location.reload();
}