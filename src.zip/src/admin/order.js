import React, { useState, useEffect } from 'react';
import AdminHeader from "./adminheader";

const MyOrder = () => {

    let [order, updateOrder] = useState([]);
    const getOrder = () => {
        fetch("http://localhost:1234/order")
            .then(response => response.json())
            .then(orderArray => {
                updateOrder(orderArray);
            })
    }

    useEffect(() => {
        getOrder();
    }, [1]);
    return (
        <>
            <AdminHeader />

            <div className="container mt-4">
                <div className="row">
                    <div className="col-lg-12 text-center">
                        <h3 className="text-info"> {order.length} Orders </h3>
                    </div>
                </div>
                {
                    order.map((myorder, index) => {
                        return (
                            <div className="row mb-5" key={index}>
                                <div className="col-lg-3">
                                    <h4> Customer Details </h4>
                                    <p> {myorder.fullname} </p>
                                    <p> {myorder.mobile} </p>
                                    <p> {myorder.email} </p>
                                    <p> {myorder.address} </p>
                                </div>
                                <div className="col-lg-9">
                                    <h6 className="text-center"> Order Id {myorder.id} </h6>
                                    <table className="table table-bordered shadow rounded">
                                        <thead>
                                            <tr className="bg-light text-primary">
                                                <th> Product Name </th>
                                                <th> Price </th>
                                                <th> Photo </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                myorder.orderitem.map((pdata, index2) => {
                                                    return (
                                                        <tr key={index2}>
                                                            <td> {pdata.name} </td>
                                                            <td> {pdata.price} </td>
                                                            <td> <img src={pdata.photo} height="50" width="60" /></td>
                                                        </tr>
                                                    )
                                                })
                                            }
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
        </>
    );
}

export default MyOrder;