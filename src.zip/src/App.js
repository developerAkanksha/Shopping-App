import React from "react";
import {HashRouter, Routes, Route} from 'react-router-dom'; 
import MyHome from "./user/home";
import MyLogin from "./user/login";
import MyCart from "./user/cart";

function UserApp() {
  return (
    <HashRouter>
      <Routes>
        <Route exact path="/" element={<MyHome/>}/>
        <Route exact path="/cart" element={<MyCart/>}/>
        <Route exact path="/login" element={<MyLogin/>}/>
      </Routes>
    </HashRouter>
  );
}

export default UserApp;
